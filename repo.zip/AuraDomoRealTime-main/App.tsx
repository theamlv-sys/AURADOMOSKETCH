
import React, { useState, useCallback, useRef, useEffect } from 'react';
import DrawingCanvas from './components/DrawingCanvas';
import { generateArtFromSketch, generateVideoFromImage, analyzeVideoForSpeech, generateMixedVoiceover } from './services/geminiService';
import { GenerationConfig, StylePreset, HistoryItem, VideoHistoryItem, VideoMode, SpeechSegment, VoiceName, VideoGenerationConfig, UserTier, VideoResolution, ModelMode } from './types';

const STYLE_PRESETS: StylePreset[] = [
  { id: 'cartoon_mix', name: 'Cartoon Mix', prompt: 'STRICT_LOCKDOWN: ULTIMATE CARTOON HYBRID. Fusion of adult sci-fi thin-line precision (Rick and Morty style), iconic yellow-saturated skin tones (Simpsons style), and sharp urban anime aesthetics (Boondocks style). MANDATORY: Rendered with high-budget Pixar-quality 3D volumetric lighting, cinematic surface scattering, and perfectly smooth textures. FORBIDDEN: Any realism, photographic skin, or real-world human features.', thumbnail: '📺' },
  { id: 'bighead', name: 'Big Head Mode', prompt: 'STRICT_LOCKDOWN: FUNNY 3D CARICATURE. Ultra-exaggerated cartoon proportions. MANDATORY: Disproportionately massive head (5x normal size), extremely tiny micro body, oversized comical giant feet, expressive playful features, high-budget 3D Disney/Pixar style render, vibrant colors. FORBIDDEN: Realistic proportions, normal human anatomy, serious lighting.', thumbnail: '🦒' },
  { id: 'aura', name: 'Aura', prompt: 'STRICT_LOCKDOWN: SIGNATURE AURA ART. High-fidelity 3D-Illustrative hybrid. MANDATORY: Glowing edges, ethereal lighting, smooth stylized surfaces. FORBIDDEN: Photorealism.', thumbnail: '✨' },
  { id: 'anime', name: 'Anime', prompt: 'STRICT_LOCKDOWN: MODERN ANIME. Sharp digital cel-shading. MANDATORY: Cinematic sky gradients, vibrant effects, iconic proportions. FORBIDDEN: 3D textures.', thumbnail: '🍱' },
  { id: 'manga', name: 'Manga Art', prompt: 'STRICT_LOCKDOWN: INK MANGA. Traditional black and white pen work. MANDATORY: Screen-tones, speed lines, deep black ink pools.', thumbnail: '📖' },
  { id: 'cine', name: 'Cinematic', prompt: 'STRICT_LOCKDOWN: CINEMATIC PHOTOGRAPHY. Film-look. MANDATORY: 35mm grain, teal/orange grading, anamorphic flares.', thumbnail: '🎬' },
  { id: 'cyber', name: 'Cyberpunk', prompt: 'STRICT_LOCKDOWN: CYBER NEON. Futuristic dark aesthetic. MANDATORY: Neon glow, rain reflections, synthetic textures.', thumbnail: '🌆' },
  { id: 'ghibli', name: 'Studio Ghibli', prompt: 'STRICT_LOCKpainted GHIBLI. Soft watercolor palettes. MANDATORY: Lush organic backgrounds, nostalgic charm.', thumbnail: '🍃' },
  { id: 'pixel', name: 'Pixel Art', prompt: 'STRICT_LOCKDOWN: 32-BIT PIXEL ART. Sharp square grid. MANDATORY: Limited palette, visible blocks. FORBIDDEN: Curves.', thumbnail: '👾' },
  { id: 'oil', name: 'Oil Painting', prompt: 'STRICT_LOCKDOWN: OIL ON CANVAS. Impasto technique. MANDATORY: Thick brushstrokes, canvas weave, wet oil sheen.', thumbnail: '🎨' },
  { id: 'photo', name: 'Hyper-Real', prompt: 'STRICT_LOCKDOWN: RAW PHOTOGRAPHY. Extreme detail. MANDATORY: Skin pores, realistic lighting, raw unedited look.', thumbnail: '📸' },
  { id: 'surreal', name: 'Surrealism', prompt: 'STRICT_LOCKDOWN: SURREALIST ART. Dream logic. MANDATORY: Bizarre juxtapositions, melting forms, painterly medium.', thumbnail: '🫠' },
  { id: 'water', name: 'Watercolor', prompt: 'STRICT_LOCKDOWN: FINE WATERCOLOR. Fluid pigments. MANDATORY: Soft bleeding edges, wet-on-wet textures.', thumbnail: '🖌️' },
  { id: 'dark', name: 'Dark Fantasy', prompt: 'STRICT_LOCKDOWN: GOTHIC FANTASY. Eldritch aesthetic. MANDATORY: Gritty textures, ominous fog, rusted metal.', thumbnail: '⚔️' },
  { id: 'ue5', name: '3D Render', prompt: 'STRICT_LOCKDOWN: UNREAL ENGINE 5. Ray-traced. MANDATORY: Subsurface scattering, cinematic 3D surfaces.', thumbnail: '🎮' },
  { id: 'pop', name: 'Pop Art', prompt: 'STRICT_LOCKDOWN: VINTAGE POP ART. Graphic impact. MANDATORY: Ben-Day dots, bold primary colors, thick outlines.', thumbnail: '💥' },
  { id: 'pencil', name: 'Pencil Art', prompt: 'STRICT_LOCKDOWN: GRAPHITE SKETCH. Hand-drawn. MANDATORY: Grayscale, lead smudges, cross-hatching, paper grain.', thumbnail: '✏️' },
  { id: 'street', name: 'Street Art', prompt: 'STRICT_LOCKDOWN: GRAFFITI MURAL. Urban spray. MANDATORY: Drips, stencil layers, brick wall texture.', thumbnail: '🏙️' },
  { id: 'abstract', name: 'Abstract Art', prompt: 'STRICT_LOCKDOWN: FINE ABSTRACT. Non-linear. MANDATORY: Dynamic shapes, emotional color usage.', thumbnail: '🎨' },
  { id: 'vapor', name: 'Vaporwave', prompt: 'STRICT_LOCKDOWN: VAPORWAVE AESTHETIC. 80s retro-futurism. MANDATORY: Pink/purple hues, glitch effects, marble statues.', thumbnail: '🌴' },
  { id: 'neonink', name: 'Neon Ink', prompt: 'STRICT_LOCKDOWN: LUMINOUS INK. Radiant lines. MANDATORY: Glowing black ink, electric cyan/magenta paths.', thumbnail: '✒️' },
  { id: 'retrocomic', name: 'Retro Comic', prompt: 'STRICT_LOCKDOWN: VINTAGE COMIC. Printed pulp. MANDATORY: Benday dots, action lines, aged paper yellowing.', thumbnail: '📰' },
  { id: 'claymation', name: 'Claymation', prompt: 'STRICT_LOCKDOWN: BRIGHT CLAYMATION. Plasticine. MANDATORY: Thumbprints, visible mold marks, vibrant clay colors.', thumbnail: '🧸' }
];

const COLORS = ['#000000', '#FFFFFF', '#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#007AFF', '#5856D6', '#AF52DE'];
const EXTENDED_COLORS = [
  '#000000', '#1a1a1a', '#4a4a4a', '#9ca3af', '#FFFFFF', 
  '#ef4444', '#dc2626', '#b91c1c', // Reds
  '#f97316', '#ea580c', '#c2410c', // Oranges
  '#f59e0b', '#d97706', '#b45309', // Ambers
  '#84cc16', '#65a30d', '#4d7c0f', // Limes
  '#10b981', '#059669', '#047857', // Emeralds
  '#06b6d4', '#0891b2', '#0e7490', // Cyans
  '#3b82f6', '#2563eb', '#1d4ed8', // Blues
  '#6366f1', '#4f46e5', '#4338ca', // Indigos
  '#8b5cf6', '#7c3aed', '#6d28d9', // Violets
  '#d946ef', '#c026d3', '#a21caf', // Fuchsias
  '#f43f5e', '#e11d48', '#be123c', // Roses
  '#78350f', '#5B21B6', '#1e293b'  // Misc
];

const ACCESS_CODE = "111111";
const VOICE_OPTIONS: VoiceName[] = ['Zephyr', 'Kore', 'Puck', 'Charon', 'Fenrir'];
const ASPECT_RATIOS: GenerationConfig['aspectRatio'][] = ['1:1', '16:9', '9:16', '4:3', '3:4'];

// --- ECONOMY CONFIG ---
const TIER_CONFIG = {
  designer: { price: 99, minutes: 100, maxRes: '720p', upscaleRes: '1K', allowRefMode: false },
  producer: { price: 199, minutes: 250, maxRes: '1080p', upscaleRes: '2K', allowRefMode: false },
  studio:   { price: 399, minutes: 600, maxRes: '4K',    upscaleRes: '4K', allowRefMode: true }
};

const BURN_RATES = {
  // Base rates
  REAL_TIME_STANDARD: 1, // 1 Aura Minute per minute (approx)
  REAL_TIME_PRO: 5,      // 5x burn for Pro model in real time (very expensive)
  
  // Per Image Costs (To offset high volume generation)
  IMAGE_GEN_STANDARD: 0.1, // Cost per single generated image (Flash)
  IMAGE_GEN_PRO: 0.2,      // Cost per single generated image (Pro) - DOUBLE Standard
  
  UPSCALE_1K: 0.5,
  UPSCALE_2K: 1,
  UPSCALE_4K: 2,
  VEO_720P: 5,
  VEO_1080P: 10,
  VEO_4K: 15
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginInput, setLoginInput] = useState('');
  
  // Economy & Tier State
  const [userTier, setUserTier] = useState<UserTier | null>(null);
  const [auraMinutes, setAuraMinutes] = useState(0);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [modelMode, setModelMode] = useState<ModelMode>('standard');

  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [color, setColor] = useState('#000000');
  const [brushSize, setBrushSize] = useState(12);
  const [opacity, setOpacity] = useState(1);
  const [tool, setTool] = useState<'brush' | 'eraser'>('brush');
  
  const [directives, setDirectives] = useState<string[]>([]);
  const [currentDirective, setCurrentDirective] = useState('');
  
  const [activeStyle, setActiveStyle] = useState(STYLE_PRESETS[0]);
  const [aspectRatio, setAspectRatio] = useState<GenerationConfig['aspectRatio']>('1:1');
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); 
  const [isExpanded, setIsExpanded] = useState(false);
  const [isRealTimePaused, setIsRealTimePaused] = useState(true); // Default to PAUSED
  
  // Tool Suite Toggle State
  const [isSuiteMinimized, setIsSuiteMinimized] = useState(false);

  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [pencilResult, setPencilResult] = useState<string | null>(null);
  const [styleResult, setStyleResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  // Video Studio State
  const [isVideoStudioOpen, setIsVideoStudioOpen] = useState(false);
  const [videoMode, setVideoMode] = useState<VideoMode>('interpolation');
  const [videoResolution, setVideoResolution] = useState<VideoResolution>('720p');
  const [videoStartFrame, setVideoStartFrame] = useState<string | null>(null);
  const [videoEndFrame, setVideoEndFrame] = useState<string | null>(null);
  const [videoIngredients, setVideoIngredients] = useState<string[]>([]);
  const [videoPrompt, setVideoPrompt] = useState('');
  const [videoLoading, setVideoLoading] = useState(false);
  const [videoStatus, setVideoStatus] = useState('');
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);

  // Dubbing State
  const [voiceInstruction, setVoiceInstruction] = useState('');
  const [dubSegments, setDubSegments] = useState<SpeechSegment[]>([]);
  const [isDubbing, setIsDubbing] = useState(false);
  const [syncedAudioUrl, setSyncedAudioUrl] = useState<string | null>(null);
  
  const [viewState, setViewState] = useState({ scale: 1, offset: { x: 0, y: 0 } });
  const [canvasKey, setCanvasKey] = useState(0);

  const currentSketchRef = useRef<string | null>(null);
  const lastGenerationTime = useRef<number>(0);

  // --- SAFETY TIMER LOGIC (Billing Only - DOES NOT TRIGGER GENERATION) ---
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isAuthenticated && userTier && !isRealTimePaused && auraMinutes > 0) {
      interval = setInterval(() => {
        setAuraMinutes(prev => {
          if (prev <= 0) {
            setIsRealTimePaused(true);
            setShowUpgradeModal(true);
            return 0;
          }
          // Burn rate depends on model
          const rate = modelMode === 'pro' ? BURN_RATES.REAL_TIME_PRO : BURN_RATES.REAL_TIME_STANDARD;
          // Deduct per second (rate / 60)
          return Math.max(0, prev - (rate/60)); 
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isAuthenticated, userTier, isRealTimePaused, auraMinutes, modelMode]);

  useEffect(() => {
    const handleResize = () => { if (window.innerWidth >= 1024) setIsSidebarOpen(true); };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginInput === ACCESS_CODE) { setIsAuthenticated(true); } else { setLoginInput(''); }
  };

  const handlePlanSelect = (tier: UserTier) => {
    setUserTier(tier);
    setAuraMinutes(TIER_CONFIG[tier].minutes);
    if (tier === 'studio') {
      setVideoResolution('4K');
      setModelMode('pro'); // Auto-enable Pro for Studio users
    }
    else if (tier === 'producer') setVideoResolution('1080p');
    else setVideoResolution('720p');
  };

  const deductCredits = (amount: number) => {
    if (auraMinutes < amount) {
      setShowUpgradeModal(true);
      throw new Error("Insufficient Aura Minutes");
    }
    setAuraMinutes(prev => prev - amount);
  };

  const ensureApiKey = async () => {
    const hasKey = await (window as any).aistudio.hasSelectedApiKey();
    if (!hasKey) await (window as any).aistudio.openSelectKey();
    return true;
  };

  const openVideoStudio = (imageUrl: string) => {
    setVideoStartFrame(imageUrl);
    setVideoEndFrame(null);
    setVideoIngredients([imageUrl]);
    setVideoPrompt('');
    setVoiceInstruction('');
    setVideoMode('interpolation');
    setGeneratedVideoUrl(null);
    setDubSegments([]);
    setSyncedAudioUrl(null);
    setIsVideoStudioOpen(true);
  };

  const handleGenerateVideo = async () => {
    if (!userTier) return;
    
    // Calculate cost based on resolution
    let cost = BURN_RATES.VEO_720P;
    if (videoResolution === '1080p') cost = BURN_RATES.VEO_1080P;
    if (videoResolution === '4K') cost = BURN_RATES.VEO_4K;

    // Check constraints
    if (videoResolution === '4K' && userTier !== 'studio') {
      setShowUpgradeModal(true);
      return;
    }
    if (videoResolution === '1080p' && userTier === 'designer') {
      setShowUpgradeModal(true);
      return;
    }

    setVideoLoading(true);
    setApiError(null);
    try {
      deductCredits(cost);
      await ensureApiKey();
      const config: VideoGenerationConfig = {
        mode: videoMode,
        prompt: videoPrompt,
        startingImage: videoStartFrame || undefined,
        endingImage: videoEndFrame || undefined,
        ingredients: videoMode === 'reference' ? videoIngredients : undefined,
        aspectRatio: '16:9', 
        model: userTier === 'studio' ? 'veo-3.1-generate-preview' : 'veo-3.1-fast-generate-preview', // Studio gets high quality
        resolution: videoResolution
      };
      const videoUrl = await generateVideoFromImage(config, (status) => setVideoStatus(status));
      if (videoUrl) setGeneratedVideoUrl(videoUrl);
    } catch (err: any) {
      if (err.message === "Insufficient Aura Minutes") return;
      setApiError("Video synthesis interrupted. Check API selection.");
      console.error(err);
    } finally {
      setVideoLoading(false);
      setVideoStatus('');
    }
  };

  const handleAnalyzeVideo = async () => {
    if (!generatedVideoUrl) return;
    setIsDubbing(true);
    setVideoStatus("Gemini is reading lips...");
    try {
      await ensureApiKey();
      const segments = await analyzeVideoForSpeech(generatedVideoUrl, voiceInstruction);
      setDubSegments(segments);
    } catch (err) {
      setApiError("Analysis failed.");
    } finally {
      setIsDubbing(false);
      setVideoStatus("");
    }
  };

  const handleForgeVoiceover = async () => {
    if (dubSegments.length === 0) return;
    setIsDubbing(true);
    setVideoStatus("Forging high-fidelity dubbing...");
    try {
      await ensureApiKey();
      // Pass voice instruction to the forge engine for perfect style application
      const audioUrl = await generateMixedVoiceover(dubSegments, voiceInstruction);
      setSyncedAudioUrl(audioUrl);
    } catch (err) {
      setApiError("Voice synthesis failed.");
    } finally {
      setIsDubbing(false);
      setVideoStatus("");
    }
  };

  const handleDownload = (url: string | null, type: 'video' | 'image' = 'image') => {
    if (!url) return;
    const link = document.createElement('a');
    link.href = url;
    link.download = type === 'video' ? `AuraVideo_${Date.now()}.mp4` : `AuraArt_${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUpscale = async (sketch: string) => {
    if (!userTier || !sketch) return;
    let cost = BURN_RATES.UPSCALE_1K;
    if (userTier === 'studio') { cost = BURN_RATES.UPSCALE_4K; }
    else if (userTier === 'producer') { cost = BURN_RATES.UPSCALE_2K; }

    try {
      deductCredits(cost);
      setIsLoading(true);
      await ensureApiKey();
      
      const config: GenerationConfig = { 
        prompt: "Highly detailed masterpiece, 8k resolution, photorealistic textures", 
        negativePrompt: "blur, low quality", 
        aspectRatio, 
        model: 'gemini-3-pro-image-preview' // Force high quality model for upscales
      };
      
      const result = await generateArtFromSketch(sketch, config, activeStyle.prompt);
      if (result) {
        handleDownload(result, 'image');
      }
    } catch (err: any) {
        if (err.message === "Insufficient Aura Minutes") return;
        setApiError("Upscale failed.");
    } finally {
        setIsLoading(false);
    }
  }

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        setReferenceImage(dataUrl);
        currentSketchRef.current = null;
        setCanvasKey(k => k + 1);
        setStyleResult(null);
        setPencilResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEndFrameUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setVideoEndFrame(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleClearPhoto = () => {
    setReferenceImage(null);
    setStyleResult(null);
    setPencilResult(null);
    setDirectives([]);
    setViewState({ scale: 1, offset: { x: 0, y: 0 } });
    currentSketchRef.current = null;
    setCanvasKey(k => k + 1);
  };

  // --- CORE GENERATION LOGIC ---
  // Added styleOverride to allow immediate generation with the selected style before state updates
  const handleGenerate = useCallback(async (sketchData: string, styleOverride?: StylePreset) => {
    const effectiveSketch = sketchData || currentSketchRef.current || "";
    if (!effectiveSketch && !referenceImage) return;
    
    // Safety: If paused or out of minutes, do NOT generate
    if (isRealTimePaused || auraMinutes <= 0) return;

    // Rate Limiting (Double check to prevent spam)
    const now = Date.now();
    if (now - lastGenerationTime.current < 500) return; // Hard 500ms limit
    lastGenerationTime.current = now;

    setIsLoading(true);
    setApiError(null);
    
    // Determine the style to use (override takes precedence)
    const currentStyle = styleOverride || activeStyle;

    try {
      // DEDUCT COST PER IMAGE GENERATED
      // Standard = 0.1, Pro = 0.2 (Double the price)
      const imageCost = modelMode === 'pro' ? BURN_RATES.IMAGE_GEN_PRO : BURN_RATES.IMAGE_GEN_STANDARD;
      deductCredits(imageCost);

      const combinedPrompt = directives.map((d, i) => `Mandatory Detail ${i+1}: ${d}`).join('\n');
      const globalNegative = "low quality, blurry, realism bleed, text, watermarks, distorted, messy, unfinished areas";
      
      // Determine Model: 'standard' (Flash) vs 'pro' (Pro Preview)
      // Standard = Nano Banana (Flash)
      // Pro = Nano Banana Pro (Gemini 3 Pro)
      const selectedModel = modelMode === 'pro' ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';

      const config: GenerationConfig = { 
        prompt: combinedPrompt, 
        negativePrompt: globalNegative, 
        aspectRatio, 
        referenceImage: referenceImage || undefined,
        model: selectedModel
      };
      
      const pencilStyle = STYLE_PRESETS.find(s => s.id === 'pencil')?.prompt || "Graphite pencil sketch.";
      
      // We only generate pencil sketch if expanded to save tokens in condensed view
      const tasks = isExpanded 
        ? [generateArtFromSketch(effectiveSketch, config, currentStyle.prompt)]
        : [
            generateArtFromSketch(effectiveSketch, config, pencilStyle),
            generateArtFromSketch(effectiveSketch, config, currentStyle.prompt)
          ];
      
      const results = await Promise.all(tasks);
      
      if (isExpanded) {
        const sRes = results[0];
        if (sRes) setStyleResult(sRes);
      } else {
        const [pRes, sRes] = results;
        if (pRes) setPencilResult(pRes);
        if (sRes) {
          setStyleResult(sRes);
          setHistory(prev => [{ id: Math.random().toString(36).substr(2, 9), sketch: effectiveSketch, result: sRes, prompt: currentStyle.name, timestamp: Date.now() }, ...prev].slice(0, 10));
        }
      }
    } catch (err: any) {
      if (err.message === "Insufficient Aura Minutes") {
        // Modal is handled by deductCredits
        return;
      }
      if (err?.message?.includes("Requested entity was not found")) {
        setApiError("Premium Session Expired. Re-select key.");
        (window as any).aistudio.openSelectKey();
      } else { 
        setApiError("Neural Synthesis Active..."); 
        console.error(err);
      }
    } finally { setIsLoading(false); }
  }, [directives, aspectRatio, activeStyle, referenceImage, isRealTimePaused, isExpanded, auraMinutes, modelMode]);

  // Triggered when user lifts mouse/finger (Final high-quality render)
  const onStrokeEnd = useCallback((sketchData: string) => {
    currentSketchRef.current = sketchData;
    if (!isRealTimePaused) {
      handleGenerate(sketchData);
    }
  }, [handleGenerate, isRealTimePaused]);

  // Triggered while drawing (Throttled real-time preview)
  const onRealTimeUpdate = useCallback((sketchData: string) => {
    currentSketchRef.current = sketchData;
    if (!isRealTimePaused) {
      handleGenerate(sketchData);
    }
  }, [handleGenerate, isRealTimePaused]);

  const toggleRealTime = () => {
    if (auraMinutes <= 0) {
      setShowUpgradeModal(true);
      return;
    }
    setIsRealTimePaused(prev => {
      const newState = !prev;
      // If unpausing, trigger a generation immediately if we have data
      if (!newState && currentSketchRef.current) handleGenerate(currentSketchRef.current);
      return newState;
    });
  };

  const addDirective = () => {
    if (!currentDirective.trim()) return;
    setDirectives([...directives, currentDirective.trim()]);
    setCurrentDirective('');
    // Trigger update on change
    if (currentSketchRef.current) handleGenerate(currentSketchRef.current);
  };

  const removeDirective = (index: number) => {
    setDirectives(directives.filter((_, i) => i !== index));
    if (currentSketchRef.current) handleGenerate(currentSketchRef.current);
  };

  const getAspectClass = () => {
    switch (aspectRatio) {
      case '16:9': return 'aspect-video';
      case '9:16': return 'aspect-[9/16]';
      case '4:3': return 'aspect-[4/3]';
      case '3:4': return 'aspect-[3/4]';
      default: return 'aspect-square';
    }
  };

  const handleStyleSelect = (style: StylePreset) => {
    setActiveStyle(style);
    if (window.innerWidth < 1024) setIsSidebarOpen(false);
    // Explicitly trigger generate on style change using the NEW style, bypassing async state wait
    if (currentSketchRef.current) handleGenerate(currentSketchRef.current, style);
  };

  const handleAspectSelect = (ratio: GenerationConfig['aspectRatio']) => {
    setAspectRatio(ratio);
    setCanvasKey(prev => prev + 1);
    // Explicitly trigger generate on aspect change
    if (currentSketchRef.current || referenceImage) handleGenerate(currentSketchRef.current || "");
  };

  const computeColor = (hex: string, alpha: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  };

  const setBrushPreset = (type: 'pencil' | 'pen' | 'marker' | 'paint') => {
    setTool('brush');
    switch (type) {
      case 'pencil': setBrushSize(2); setOpacity(0.8); break;
      case 'pen': setBrushSize(4); setOpacity(1); break;
      case 'marker': setBrushSize(16); setOpacity(0.5); break;
      case 'paint': setBrushSize(32); setOpacity(0.9); break;
    }
  };

  // --- SCREENS ---

  if (!isAuthenticated) {
    return (
      <div className="h-screen w-screen bg-[#050505] flex items-center justify-center">
        <div className="w-full max-w-[320px] text-center p-6">
          <div className="w-20 h-20 rounded-3xl bg-indigo-600 mx-auto mb-8 flex items-center justify-center text-4xl shadow-[0_0_50px_rgba(79,70,229,0.3)]">✨</div>
          <h1 className="text-4xl font-black italic uppercase text-white mb-8">Aura<span className="text-indigo-500">Artist</span></h1>
          <form onSubmit={handleLogin} className="space-y-4">
            <input type="password" value={loginInput} onChange={(e) => setLoginInput(e.target.value)} placeholder="••••••" className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-center text-2xl tracking-[0.8em] text-white outline-none focus:border-indigo-500/50 transition-all" />
            <button type="submit" className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-lg active:scale-95 transition-all">Enter Studio</button>
          </form>
        </div>
      </div>
    );
  }

  // PLAN SELECTION SCREEN
  if (!userTier) {
    return (
      <div className="h-screen w-screen bg-[#020202] text-white flex flex-col items-center justify-center p-6 overflow-y-auto">
        <h2 className="text-3xl font-black uppercase italic mb-2 tracking-tighter">Select Your <span className="text-indigo-500">Power</span></h2>
        <p className="text-slate-400 text-sm mb-12 font-mono uppercase tracking-widest">Choose your compute allocation</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-6xl">
          {/* DESIGNER */}
          <div className="p-8 rounded-3xl bg-white/5 border border-white/10 hover:border-indigo-500/50 transition-all group flex flex-col">
            <h3 className="text-xl font-black uppercase tracking-widest mb-2">Designer</h3>
            <div className="text-4xl font-bold mb-6">$99<span className="text-sm font-normal text-slate-500">/mo</span></div>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex gap-3 text-sm"><span className="text-indigo-400">✓</span> 100 Aura Minutes</li>
              <li className="flex gap-3 text-sm"><span className="text-indigo-400">✓</span> Real-Time Drawing (Flash)</li>
              <li className="flex gap-3 text-sm text-slate-400"><span className="text-slate-600">Locked</span> Veo Fast (720p Only)</li>
              <li className="flex gap-3 text-sm text-slate-400"><span className="text-slate-600">Locked</span> Standard Upscaling (1K)</li>
            </ul>
            <button onClick={() => handlePlanSelect('designer')} className="w-full py-4 rounded-xl bg-white/10 hover:bg-white/20 font-black uppercase text-[10px] tracking-[0.2em] transition-all">Select Designer</button>
          </div>

          {/* PRODUCER */}
          <div className="p-8 rounded-3xl bg-gradient-to-b from-indigo-900/20 to-black border border-indigo-500/30 relative overflow-hidden flex flex-col transform hover:-translate-y-2 transition-all">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent" />
            <h3 className="text-xl font-black uppercase tracking-widest mb-2 text-indigo-400">Producer</h3>
            <div className="text-4xl font-bold mb-6">$199<span className="text-sm font-normal text-slate-500">/mo</span></div>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex gap-3 text-sm"><span className="text-indigo-400">✓</span> 250 Aura Minutes</li>
              <li className="flex gap-3 text-sm"><span className="text-indigo-400">✓</span> Priority Real-Time Speed</li>
              <li className="flex gap-3 text-sm"><span className="text-indigo-400">✓</span> Veo Standard (1080p)</li>
              <li className="flex gap-3 text-sm"><span className="text-indigo-400">✓</span> 2K Image Upscaling</li>
            </ul>
            <button onClick={() => handlePlanSelect('producer')} className="w-full py-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-black uppercase text-[10px] tracking-[0.2em] transition-all shadow-lg shadow-indigo-900/50">Select Producer</button>
          </div>

          {/* STUDIO - WHALE TIER */}
          <div className="p-8 rounded-3xl bg-white/5 border border-yellow-500/20 hover:border-yellow-500/50 transition-all flex flex-col relative overflow-hidden">
            <div className="absolute -right-12 top-6 bg-yellow-500 text-black font-black text-[9px] uppercase tracking-widest py-1 px-12 rotate-45">Best Value</div>
            <h3 className="text-xl font-black uppercase tracking-widest mb-2 text-yellow-500">Studio</h3>
            <div className="text-4xl font-bold mb-6">$399<span className="text-sm font-normal text-slate-500">/mo</span></div>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex gap-3 text-sm"><span className="text-yellow-500">✓</span> 600 Aura Minutes</li>
              <li className="flex gap-3 text-sm"><span className="text-yellow-500">✓</span> 🔓 <span className="text-white font-bold">Veo 3.1 4K Cinema</span></li>
              <li className="flex gap-3 text-sm"><span className="text-yellow-500">✓</span> 🔓 <span className="text-white font-bold">Gemini 3 Pro 4K Upscale</span></li>
              <li className="flex gap-3 text-sm"><span className="text-yellow-500">✓</span> Commercial License</li>
            </ul>
            <button onClick={() => handlePlanSelect('studio')} className="w-full py-4 rounded-xl bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-500 hover:to-amber-500 font-black uppercase text-[10px] tracking-[0.2em] transition-all shadow-lg">Enter Studio</button>
          </div>
        </div>
      </div>
    );
  }

  // MAIN APP
  return (
    <div className={`h-screen flex flex-col transition-all duration-700 ${theme === 'dark' ? 'bg-[#030303] text-slate-200' : 'bg-[#fcfcfc] text-slate-900'} overflow-hidden font-sans`}>
      {/* UPGRADE MODAL */}
      {showUpgradeModal && (
        <div className="fixed inset-0 z-[999] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-[#111] border border-white/10 rounded-3xl p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-indigo-600/20 text-indigo-500 flex items-center justify-center mx-auto mb-6">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            </div>
            <h3 className="text-2xl font-black uppercase italic text-white mb-2">Insufficient Aura</h3>
            <p className="text-slate-400 text-sm mb-8">You have run out of compute minutes for this high-fidelity task. Recharge to continue creating.</p>
            <div className="grid gap-3">
              <button onClick={() => { setAuraMinutes(prev => prev + 50); setShowUpgradeModal(false); }} className="w-full py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl flex items-center justify-between px-6 group">
                <span className="font-bold text-white">50 Minutes</span>
                <span className="text-indigo-400 font-mono">$50</span>
              </button>
              <button onClick={() => { setAuraMinutes(prev => prev + 150); setShowUpgradeModal(false); }} className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 rounded-xl flex items-center justify-between px-6 shadow-lg shadow-indigo-900/40">
                <span className="font-bold text-white uppercase tracking-widest text-xs">Best Value: 150 Minutes</span>
                <span className="text-white font-mono">$99</span>
              </button>
            </div>
            <button onClick={() => setShowUpgradeModal(false)} className="mt-6 text-slate-500 text-xs font-black uppercase tracking-widest hover:text-white">Cancel</button>
          </div>
        </div>
      )}

      <nav className={`h-16 flex items-center justify-between px-4 md:px-6 border-b transition-all duration-500 z-[100] flex-shrink-0 ${theme === 'dark' ? 'border-white/5 bg-black/40 backdrop-blur-xl' : 'border-slate-100 bg-white/80 backdrop-blur-xl shadow-sm'}`}>
        <div className="flex items-center gap-3 md:gap-4">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className={`p-2 rounded-xl transition-all ${theme === 'dark' ? 'hover:bg-white/5 text-slate-400' : 'hover:bg-slate-100 text-slate-500'}`}>
            <svg className={`w-5 h-5 transition-transform duration-500 ${isSidebarOpen ? '' : 'rotate-180'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" /></svg>
          </button>
          <div className="flex items-center gap-2 md:gap-3">
            <div className="w-6 h-6 md:w-8 md:h-8 rounded-xl bg-indigo-600 shadow-lg flex items-center justify-center text-[10px]">✨</div>
            <span className={`font-black text-sm md:text-xl tracking-tighter uppercase italic ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Aura<span className="text-indigo-600">Artist</span></span>
          </div>
        </div>
        
        {/* ECONOMY DASHBOARD HEADER */}
        <div className="flex items-center gap-4 bg-black/20 border border-white/5 rounded-full px-4 py-1.5 backdrop-blur-md">
           <div className={`w-2 h-2 rounded-full ${auraMinutes > 20 ? 'bg-green-500' : 'bg-red-500 animate-pulse'}`} />
           <span className="text-[10px] font-mono text-slate-300">
             <span className="font-bold text-white">{Math.floor(auraMinutes)}</span> MINS
           </span>
           <div className="h-3 w-px bg-white/10" />
           <span className="text-[9px] font-black uppercase tracking-widest text-indigo-400">{userTier}</span>
        </div>

        {/* MODEL MODE TOGGLE (Standard vs Pro) */}
        {userTier !== 'designer' && (
           <div className="flex items-center bg-black/20 border border-white/5 rounded-full p-1 backdrop-blur-md">
              <button 
                onClick={() => setModelMode('standard')} 
                className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest transition-all ${modelMode === 'standard' ? 'bg-white/10 text-white shadow-sm' : 'text-slate-500 hover:text-white'}`}
              >
                Standard
              </button>
              <button 
                onClick={() => setModelMode('pro')} 
                className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest transition-all ${modelMode === 'pro' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
              >
                Pro
              </button>
           </div>
        )}

        <div className="flex items-center gap-2 md:gap-3">
          <button onClick={() => setShowUpgradeModal(true)} className={`hidden md:block px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all bg-indigo-600 text-white shadow-lg hover:bg-indigo-500`}>
            Add Time
          </button>
          <button onClick={toggleTheme} className={`w-8 h-8 md:w-10 md:h-10 flex items-center justify-center rounded-full transition-all ${theme === 'dark' ? 'bg-white/5 text-yellow-400 hover:bg-white/10' : 'bg-slate-50 text-slate-600 hover:bg-slate-200'}`}>
            {theme === 'dark' ? <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707M16.243 17.657l.707.707M7.757 7.757l.707-.707M12 7a5 5 0 110 10 5 5 0 010-10z" /></svg> : <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>}
          </button>
          <div className="h-6 w-px bg-slate-200 mx-1 md:mx-2" />
          {referenceImage ? (
            <button onClick={handleClearPhoto} className="px-3 md:px-5 py-1.5 md:py-2 bg-red-600 text-white rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg">Clear</button>
          ) : (
            <label className="cursor-pointer px-3 md:px-5 py-1.5 md:py-2 bg-indigo-600 border border-indigo-500 text-white rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all">
              Upload
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>
          )}
        </div>
      </nav>

      <main className="flex-1 flex overflow-hidden relative">
        {isSidebarOpen && <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[85] lg:hidden" onClick={() => setIsSidebarOpen(false)} />}
        <aside className={`fixed inset-y-0 left-0 w-[280px] md:w-[300px] border-r transition-all duration-500 z-[90] flex flex-col p-6 md:p-8 gap-6 md:gap-8 overflow-y-auto no-scrollbar lg:relative ${theme === 'dark' ? 'bg-[#080808] border-white/5 shadow-2xl' : 'bg-white border-slate-100 shadow-sm'} ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:-ml-[300px] opacity-0 pointer-events-none'}`}>
          <section>
             <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600 mb-6">Canvas Ratio</h3>
             <div className="flex flex-wrap gap-2">
               {ASPECT_RATIOS.map(ratio => (
                 <button 
                  key={ratio} 
                  onClick={() => handleAspectSelect(ratio)}
                  className={`px-3 py-2 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all ${aspectRatio === ratio ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : `${theme === 'dark' ? 'bg-white/5 border-white/10 text-slate-500' : 'bg-slate-50 border-slate-100 text-slate-500'}`}`}
                 >
                   {ratio}
                 </button>
               ))}
             </div>
          </section>

          <section>
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600 mb-6">Engine Styles</h3>
            <div className="grid grid-cols-2 gap-3 pb-4">
              {STYLE_PRESETS.map(style => (
                <button key={style.id} onClick={() => handleStyleSelect(style)} className={`p-3 md:p-4 rounded-[1.25rem] border transition-all text-left flex flex-col gap-2 ${activeStyle.id === style.id ? 'bg-indigo-600 border-indigo-600 shadow-lg ring-4 ring-indigo-600/20' : `${theme === 'dark' ? 'bg-white/5 border-white/10' : 'bg-slate-50 border-slate-100 shadow-sm'}`}`}>
                  <span className="text-xl md:text-2xl">{style.thumbnail}</span>
                  <span className={`text-[8px] md:text-[9px] font-black uppercase tracking-tight ${activeStyle.id === style.id ? 'text-white' : (theme === 'dark' ? 'text-slate-400' : 'text-slate-600')}`}>{style.name}</span>
                </button>
              ))}
            </div>
          </section>

          <section className="space-y-6">
             <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600">Commands</h3>
             <div className="flex gap-2">
               <input value={currentDirective} onChange={(e) => setCurrentDirective(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addDirective()} placeholder="Specific detail..." className={`flex-1 border rounded-xl px-4 py-2 text-[10px] font-medium outline-none transition-all ${theme === 'dark' ? 'bg-white/5 border-white/10 text-white' : 'bg-slate-50 border-slate-100 text-slate-900'}`} />
               <button onClick={addDirective} className="bg-indigo-600 text-white w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center shadow-lg">+</button>
             </div>
             <div className="flex flex-wrap gap-2">
               {directives.map((dir, idx) => (
                 <div key={idx} className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-[8px] md:text-[10px] font-bold border transition-all ${theme === 'dark' ? 'bg-indigo-600/20 border-indigo-600/30 text-indigo-400' : 'bg-indigo-50 border-indigo-100 text-indigo-700'}`}>
                   <span>{dir}</span>
                   <button onClick={() => removeDirective(idx)} className="hover:text-red-500 font-black">×</button>
                 </div>
               ))}
             </div>
          </section>

          <section className="mt-auto pt-6 border-slate-100 space-y-6">
            <div className={`grid grid-cols-2 gap-2 p-1 rounded-[1.5rem] border ${theme === 'dark' ? 'bg-black/50 border-white/5' : 'bg-slate-100 border-slate-200'}`}>
              <button onClick={() => setTool('brush')} className={`flex flex-col items-center justify-center gap-1 py-3 md:py-4 rounded-2xl transition-all ${tool === 'brush' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}>
                <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                <span className="text-[7px] font-black uppercase">Draw</span>
              </button>
              <button onClick={() => setTool('eraser')} className={`flex flex-col items-center justify-center gap-1 py-3 md:py-4 rounded-2xl transition-all ${tool === 'eraser' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}>
                <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 7l-.867 12.142A2 2.001 16.138 21H7.862a2 2 0 01-1.995-1.858L5 7" /></svg>
                <span className="text-[7px] font-black uppercase">Erase</span>
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between text-[9px] font-black uppercase text-slate-400"><span>Stroke Size</span><span className="text-indigo-600">{brushSize}px</span></div>
              <input type="range" min="2" max="150" value={brushSize} onChange={(e) => setBrushSize(parseInt(e.target.value))} className="w-full accent-indigo-600 h-1 bg-slate-200 rounded-full appearance-none cursor-pointer" />
              <div className="flex gap-2 justify-center pt-2">
                {COLORS.map(c => <button key={c} onClick={() => {setColor(c); setTool('brush');}} className={`w-5 h-5 md:w-6 md:h-6 rounded-full border-2 transition-all ${color === c && tool === 'brush' ? 'border-indigo-600 scale-125 shadow-lg' : 'border-transparent opacity-60'}`} style={{backgroundColor: c}} />)}
              </div>
            </div>
          </section>
        </aside>

        <section className={`flex-1 flex flex-col overflow-hidden ${theme === 'dark' ? 'bg-[#030303]' : 'bg-[#fcfcfc]'}`}>
          <div className="flex-1 relative flex flex-col p-4 md:p-10 items-center overflow-y-auto no-scrollbar">
            {apiError && <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-6 md:px-8 py-2 md:py-3 rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-[0.3em] z-[200] animate-pulse shadow-2xl">{apiError}</div>}
            <div className={`flex flex-col gap-6 md:gap-8 w-full max-w-[1600px] ${isExpanded ? 'h-full' : ''}`}>
              <div className={`flex flex-col transition-all duration-500 ${isExpanded ? 'fixed inset-0 z-[110] bg-black' : 'w-full h-[320px] md:h-[450px]'}`}>
                <div className={`flex items-center justify-between mb-4 px-2 ${isExpanded ? 'absolute top-6 left-6 right-6 z-[120]' : ''}`}>
                  <span className={`text-[8px] md:text-[10px] font-black uppercase tracking-[0.3em] ${theme === 'dark' || isExpanded ? 'text-white/50' : 'text-slate-400'}`}>{referenceImage ? 'Base Reference' : 'Drawing Pad'}</span>
                  
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={toggleRealTime}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all shadow-lg ${isRealTimePaused ? 'bg-green-600 text-white hover:bg-green-500' : 'bg-yellow-500 text-black hover:bg-yellow-400'}`}
                    >
                      {isRealTimePaused ? (
                        <><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>Resume AI</>
                      ) : (
                        <><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>Pause AI</>
                      )}
                    </button>
                    
                    <button onClick={() => setIsExpanded(!isExpanded)} className={`p-2 rounded-xl transition-all shadow-lg ${isExpanded ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-indigo-600/10 text-indigo-600 hover:bg-indigo-600/20'}`}>{isExpanded ? <div className="flex items-center gap-2"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg><span className="hidden md:inline text-[10px] font-black uppercase tracking-widest px-1">Exit Artist Mode</span></div> : <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>}</button>
                  </div>
                </div>
                <div className={`w-full flex-1 overflow-hidden transition-all duration-500 ${isExpanded ? '' : 'rounded-[1.5rem] md:rounded-[2.5rem] border'} ${theme === 'dark' ? 'border-white/5 bg-black' : 'border-slate-100 bg-white shadow-xl'}`}>
                  <DrawingCanvas 
                    key={canvasKey} 
                    color={isExpanded ? computeColor(color, opacity) : color} 
                    brushSize={brushSize} 
                    tool={tool} 
                    onStrokeEnd={onStrokeEnd} 
                    onRealTimeUpdate={onRealTimeUpdate} 
                    aspectRatio={aspectRatio} 
                    scale={viewState.scale} 
                    offset={viewState.offset} 
                    onTransformChange={(s, o) => setViewState({ scale: s, offset: o })} 
                    backgroundImage={referenceImage} 
                  />
                </div>
                
                {isExpanded && (
                  <>
                    {/* TOOL SUITE - POSITIONED BOTTOM-CENTER WHEN OPEN, BOTTOM-RIGHT WHEN MINIMIZED */}
                    <div 
                      className={`absolute bg-[#0f172a]/95 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-[0_40px_100px_rgba(0,0,0,0.8)] z-[140] animate-in slide-in-from-bottom-10 fade-in duration-300 overflow-hidden flex flex-col pointer-events-auto transition-all duration-300`}
                      style={isSuiteMinimized ? {
                        right: '40px',
                        bottom: '40px',
                        width: '160px'
                      } : {
                        left: '50%',
                        bottom: '40px',
                        width: '90%',
                        maxWidth: '650px',
                        transform: 'translateX(-50%)'
                      }}
                    >
                      {/* HEADER / TOGGLE */}
                      <div className="h-8 w-full bg-white/5 flex items-center justify-center border-b border-white/5 relative">
                        <div className="w-12 h-1 rounded-full bg-white/20" />
                        <button 
                          onClick={() => setIsSuiteMinimized(!isSuiteMinimized)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:text-white text-white/50 transition-colors"
                        >
                          {isSuiteMinimized ? (
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>
                          ) : (
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M20 12H4" /></svg>
                          )}
                        </button>
                      </div>

                      {!isSuiteMinimized ? (
                        <div className="p-5 flex flex-col gap-5">
                          <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-1">
                            {EXTENDED_COLORS.map(c => (
                              <button key={c} onClick={() => {setColor(c); setTool('brush');}} className={`w-9 h-9 rounded-full border-2 flex-shrink-0 transition-all ${color === c && tool === 'brush' ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-80 hover:scale-105'}`} style={{backgroundColor: c}} />
                            ))}
                          </div>
                          
                          <div className="h-px bg-white/10 w-full" />
                          
                          <div className="flex items-center justify-between gap-6">
                            <div className="flex items-center gap-1">
                              <button onClick={() => setBrushPreset('pencil')} className={`p-3 rounded-xl transition-all ${brushSize < 5 && tool === 'brush' ? 'bg-white/10 text-indigo-400' : 'text-slate-400 hover:text-white hover:bg-white/5'}`} title="Pencil">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                              </button>
                              <button onClick={() => setBrushPreset('pen')} className={`p-3 rounded-xl transition-all ${brushSize >= 5 && brushSize < 12 && tool === 'brush' ? 'bg-white/10 text-indigo-400' : 'text-slate-400 hover:text-white hover:bg-white/5'}`} title="Pen">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                              </button>
                              <button onClick={() => setBrushPreset('marker')} className={`p-3 rounded-xl transition-all ${brushSize >= 12 && brushSize < 24 && tool === 'brush' ? 'bg-white/10 text-indigo-400' : 'text-slate-400 hover:text-white hover:bg-white/5'}`} title="Marker">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                              </button>
                              <button onClick={() => setBrushPreset('paint')} className={`p-3 rounded-xl transition-all ${brushSize >= 24 && tool === 'brush' ? 'bg-white/10 text-indigo-400' : 'text-slate-400 hover:text-white hover:bg-white/5'}`} title="Paint Brush">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" /></svg>
                              </button>
                            </div>

                            <div className="flex-1 flex flex-col gap-3 px-6 border-l border-r border-white/10">
                              <div className="flex items-center gap-4">
                                <span className="text-[10px] font-black uppercase text-slate-500 w-12">Size</span>
                                <input type="range" min="1" max="150" value={brushSize} onChange={(e) => setBrushSize(parseInt(e.target.value))} className="flex-1 accent-indigo-500 h-1 bg-white/10 rounded-full appearance-none" />
                              </div>
                              <div className="flex items-center gap-4">
                                <span className="text-[10px] font-black uppercase text-slate-500 w-12">Flow</span>
                                <input type="range" min="0.1" max="1" step="0.1" value={opacity} onChange={(e) => setOpacity(parseFloat(e.target.value))} className="flex-1 accent-indigo-500 h-1 bg-white/10 rounded-full appearance-none" />
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <button onClick={() => setTool('eraser')} className={`p-4 rounded-2xl transition-all ${tool === 'eraser' ? 'bg-indigo-600 text-white shadow-xl' : 'hover:bg-white/5 text-slate-400'}`} title="Eraser">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2.001 16.138 21H7.862a2 2 0 01-1.995-1.858L5 7" /></svg>
                              </button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="px-5 py-4 flex items-center justify-between gap-5">
                           <div className="flex items-center gap-4">
                              <div className="w-8 h-8 rounded-full border-2 border-white/30 shadow-inner" style={{ backgroundColor: tool === 'eraser' ? 'transparent' : color }}>
                                 {tool === 'eraser' && <svg className="w-4 h-4 text-white m-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 7l-.867 12.142A2 2.001 16.138 21H7.862a2 2 0 01-1.995-1.858L5 7" /></svg>}
                              </div>
                              <div className="flex flex-col">
                                <span className="text-[10px] font-black uppercase text-white tracking-widest">{tool}</span>
                                <span className="text-[8px] font-mono text-indigo-400/70">{brushSize}px</span>
                              </div>
                           </div>
                           <div className="flex gap-2">
                              <button onClick={() => setTool('brush')} className={`p-2.5 rounded-xl ${tool === 'brush' ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg></button>
                              <button onClick={() => setTool('eraser')} className={`p-2.5 rounded-xl ${tool === 'eraser' ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2.001 16.138 21H7.862a2 2 0 01-1.995-1.858L5 7" /></svg></button>
                           </div>
                        </div>
                      )}
                    </div>

                    {/* LIVE PREVIEW - SLIGHTLY OFFSET IF SUITE IS IN RIGHT CORNER */}
                    <div className={`absolute z-[130] w-56 md:w-96 pointer-events-none transition-all duration-300 ${isSuiteMinimized ? 'bottom-32 right-10' : 'bottom-10 right-10'}`}>
                      <div className={`w-full ${getAspectClass()} rounded-[2rem] border-2 border-indigo-600/40 overflow-hidden shadow-[0_40px_100px_rgba(0,0,0,0.9)] relative bg-black/60 backdrop-blur-3xl pointer-events-auto group`}>
                        <div className="absolute top-4 left-5 z-20 flex items-center gap-2"><div className={`w-2 h-2 rounded-full ${isLoading ? 'bg-yellow-500 animate-ping' : 'bg-green-500'}`} /><span className="text-[9px] font-black uppercase tracking-[0.2em] text-white/90 drop-shadow-lg">Aura Live: {activeStyle.name}</span></div>
                        {styleResult ? <img src={styleResult} className={`w-full h-full object-cover transition-all duration-300 ${isLoading ? 'opacity-40 blur-xl scale-105' : 'opacity-100 scale-100'}`} /> : <div className="absolute inset-0 flex items-center justify-center bg-white/5"><span className="text-[10px] font-black uppercase tracking-[0.4em] italic text-white/20">Initializing...</span></div>}
                        {isLoading && <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[6px] z-10"><div className="w-12 h-12 border-[4px] border-indigo-500 border-t-transparent rounded-full animate-spin" /></div>}
                        {styleResult && (
                          <button onClick={() => handleDownload(styleResult)} className="absolute bottom-5 right-5 p-3 bg-indigo-600 hover:bg-indigo-700 rounded-full text-white shadow-2xl opacity-0 group-hover:opacity-100 transition-all active:scale-90">
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                          </button>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
              
              {/* DASHBOARD GRID */}
              <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 w-full transition-all duration-500 ${isExpanded ? 'opacity-0 h-0 overflow-hidden' : ''}`}>
                <div className="flex flex-col gap-3 md:gap-4">
                  <div className="flex items-center justify-between px-2">
                    <span className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">Aura Blueprint</span>
                    {pencilResult && <button onClick={() => handleDownload(pencilResult)} className="text-[8px] md:text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:text-indigo-600 transition-all">Download</button>}
                  </div>
                  <div className={`w-full ${getAspectClass()} rounded-[1.5rem] md:rounded-[2.5rem] overflow-hidden border relative ${theme === 'dark' ? 'border-white/5 bg-black' : 'border-slate-100 bg-white shadow-xl'}`}>
                    {pencilResult ? <img src={pencilResult} className={`w-full h-full object-cover transition-all duration-500 ${isLoading ? 'opacity-30 blur-xl' : 'opacity-100'}`} /> : <div className="absolute inset-0 flex items-center justify-center opacity-10"><span className="text-[9px] font-black uppercase tracking-[0.5em] italic">Waiting...</span></div>}
                  </div>
                </div>
                <div className="flex flex-col gap-3 md:gap-4">
                  <div className="flex items-center justify-between px-2">
                    <span className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600">Final Masterpiece</span>
                    <div className="flex gap-4">
                      {styleResult && !isLoading && <button onClick={() => handleDownload(styleResult)} className="text-[8px] md:text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:text-indigo-600">Download</button>}
                      {styleResult && !isLoading && <button onClick={() => currentSketchRef.current && handleUpscale(currentSketchRef.current)} className={`text-[8px] md:text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:text-indigo-600 transition-all ${userTier === 'designer' ? 'opacity-50 cursor-not-allowed' : ''}`}>Upscale {TIER_CONFIG[userTier!].upscaleRes}</button>}
                      {styleResult && !isLoading && <button onClick={() => styleResult && openVideoStudio(styleResult)} className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.1em] text-indigo-600">Animate</button>}
                    </div>
                  </div>
                  <div className={`w-full ${getAspectClass()} rounded-[1.5rem] md:rounded-[2.5rem] overflow-hidden border relative ${theme === 'dark' ? 'border-white/5 bg-black' : 'border-slate-100 bg-white shadow-xl'}`}>
                    {styleResult ? <img src={styleResult} className={`w-full h-full object-cover transition-all duration-700 ${isLoading ? 'opacity-30 blur-xl' : 'opacity-100'}`} /> : <div className="absolute inset-0 flex items-center justify-center opacity-10"><span className="text-[9px] font-black uppercase tracking-[0.5em] italic">Genesis...</span></div>}{isLoading && <div className="absolute inset-0 flex items-center justify-center bg-black/10 backdrop-blur-md z-10"><div className="w-8 h-8 md:w-10 md:h-10 border-[2px] border-indigo-600 border-t-transparent rounded-full animate-spin" /></div>}</div></div>
              </div>
            </div>
            {!isExpanded && (
              <div className="w-full max-w-[1000px] py-12 md:py-16 flex flex-col items-center gap-6">
                 <h3 className="text-[10px] font-black uppercase tracking-[0.5em] text-slate-500">History</h3>
                 <div className="flex gap-3 md:gap-5 overflow-x-auto no-scrollbar px-4 w-full justify-start md:justify-center">
                    {history.map(item => <div key={item.id} className="relative group w-16 h-16 md:w-24 md:h-24 flex-shrink-0"><div onClick={() => setStyleResult(item.result)} className="w-full h-full rounded-[1rem] md:rounded-[1.5rem] border cursor-pointer overflow-hidden group-hover:scale-110 active:scale-95 transition-all bg-white border-slate-100 shadow-lg"><img src={item.result} className="w-full h-full object-cover" /></div></div>)}
                 </div>
              </div>
            )}
          </div>
        </section>
      </main>

      {isVideoStudioOpen && (
        <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-2 md:p-8 animate-in fade-in zoom-in duration-300">
          <div className="w-full max-w-5xl h-full md:h-auto md:max-h-[90vh] bg-[#080808] border border-white/10 rounded-[2rem] md:rounded-[3rem] overflow-hidden flex flex-col md:flex-row shadow-[0_50px_100px_rgba(0,0,0,0.8)]">
            <div className="flex-1 bg-black p-4 md:p-6 flex flex-col items-center justify-center relative min-h-[300px] md:min-h-[400px]">
              <div className="absolute top-4 left-4 z-10 flex items-center gap-3">
                <button onClick={() => setIsVideoStudioOpen(false)} className="p-2 bg-indigo-600/20 text-indigo-400 rounded-xl hover:bg-indigo-600/30 transition-all" title="Return Home">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
                </button>
                <span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.3em] text-indigo-500">Video Studio</span>
              </div>
              <div className="w-full aspect-video bg-white/5 rounded-[1rem] md:rounded-[2rem] overflow-hidden border border-white/5 relative shadow-inner">
                {videoLoading || isDubbing ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 p-4 text-center"><div className="w-10 h-10 md:w-16 md:h-16 border-[3px] md:border-[4px] border-indigo-600 border-t-transparent rounded-full animate-spin" /><p className="text-white font-black uppercase text-[10px] md:text-[12px] tracking-widest animate-pulse">{videoStatus || 'Synthesizing...'}</p></div>
                ) : generatedVideoUrl ? (
                  <div className="w-full h-full relative">
                    <video src={generatedVideoUrl} id="videoPlayer" controls autoPlay loop className="w-full h-full object-contain" />
                    {syncedAudioUrl && <audio src={syncedAudioUrl} autoPlay />}
                  </div>
                ) : (
                  <div className="relative w-full h-full flex items-center justify-center group bg-[#050505] overflow-hidden">
                    <div className="absolute inset-0 flex gap-1">
                      {videoStartFrame && <img src={videoStartFrame} className={`h-full object-cover ${videoEndFrame ? 'w-1/2' : 'w-full'} opacity-40`} />}
                      {videoEndFrame && <img src={videoEndFrame} className="w-1/2 h-full object-cover opacity-40" />}
                    </div>
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center"><span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.5em] text-white/40 text-center">Awaiting Synthesis</span></div>
                  </div>
                )}
              </div>
              {generatedVideoUrl && !isDubbing && (
                <div className="flex flex-col items-center gap-4 mt-6 w-full max-w-sm">
                   <div className="w-full space-y-2">
                     <p className="text-[8px] font-black uppercase tracking-[0.2em] text-white/50 px-2">Voice Direction & Tone</p>
                     <textarea value={voiceInstruction} onChange={(e) => setVoiceInstruction(e.target.value)} placeholder="Perfectly describe how you want them to sound (e.g. Gritty pirate, rapid-fire cartoon, emotional whisper)..." className="w-full h-16 bg-white/5 border border-white/10 rounded-xl p-3 text-[10px] text-white outline-none focus:border-indigo-500/50 resize-none shadow-inner" />
                   </div>
                  <div className="flex gap-4 w-full">
                    <button onClick={handleAnalyzeVideo} className="w-full py-2 md:py-3 bg-indigo-600 text-white rounded-full font-black uppercase text-[8px] md:text-[10px] tracking-[0.2em] shadow-xl hover:bg-indigo-700 transition-all">Scan for AI Voice</button>
                  </div>
                </div>
              )}
            </div>

            <div className="w-full md:w-[360px] lg:w-[400px] p-6 md:p-8 border-t md:border-t-0 md:border-l border-white/5 flex flex-col gap-4 md:gap-6 overflow-y-auto no-scrollbar">
              <div className="flex items-center justify-between"><h2 className="text-lg md:text-xl font-black uppercase italic tracking-tighter">Veo<span className="text-indigo-600">Studio</span></h2><button onClick={() => setIsVideoStudioOpen(false)} className="text-slate-500 hover:text-white transition-colors"><svg className="w-5 h-5 md:w-6 md:h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg></button></div>
              
              {!dubSegments.length ? (
                <>
                  <div className="flex p-1 bg-white/5 rounded-xl border border-white/5"><button onClick={() => setVideoMode('interpolation')} className={`flex-1 py-2 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all ${videoMode === 'interpolation' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500'}`}>Story Mode</button><button onClick={() => userTier === 'studio' ? setVideoMode('reference') : setApiError("Vision mode requires Studio plan.")} className={`flex-1 py-2 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all ${videoMode === 'reference' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500'} ${userTier !== 'studio' ? 'opacity-40' : ''}`}>Vision Mode {userTier !== 'studio' && '🔒'}</button></div>
                  
                  {videoMode === 'interpolation' && (
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <span className="text-[8px] font-black uppercase text-white/40 tracking-widest">Start Frame</span>
                        <div className="aspect-video rounded-xl border border-white/10 overflow-hidden bg-white/5 shadow-inner">
                          <img src={videoStartFrame!} className="w-full h-full object-cover" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <span className="text-[8px] font-black uppercase text-white/40 tracking-widest">End Frame</span>
                        <label className="block aspect-video rounded-xl border border-dashed border-white/20 hover:border-indigo-500/50 cursor-pointer overflow-hidden relative bg-white/5 transition-all shadow-inner">
                          {videoEndFrame ? (
                            <img src={videoEndFrame} className="w-full h-full object-cover" />
                          ) : (
                            <div className="absolute inset-0 flex items-center justify-center text-[10px] text-white/20 font-black">+ ADD</div>
                          )}
                          <input type="file" accept="image/*" onChange={handleEndFrameUpload} className="hidden" />
                        </label>
                      </div>
                    </div>
                  )}

                  <section className="space-y-2">
                     <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-500">Quality Output</h3>
                     <div className="grid grid-cols-3 gap-2">
                        <button onClick={() => setVideoResolution('720p')} className={`py-2 rounded-lg border text-[9px] font-black ${videoResolution === '720p' ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-white/10 text-slate-500'}`}>720p</button>
                        <button onClick={() => setVideoResolution('1080p')} className={`py-2 rounded-lg border text-[9px] font-black ${videoResolution === '1080p' ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-white/10 text-slate-500'} ${userTier === 'designer' ? 'opacity-30' : ''}`}>{userTier === 'designer' ? '🔒 1080p' : '1080p'}</button>
                        <button onClick={() => setVideoResolution('4K')} className={`py-2 rounded-lg border text-[9px] font-black ${videoResolution === '4K' ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-white/10 text-slate-500'} ${userTier !== 'studio' ? 'opacity-30' : ''}`}>{userTier !== 'studio' ? '🔒 4K' : '4K'}</button>
                     </div>
                  </section>

                  <section className="space-y-4"><h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-500">Atmosphere Directives</h3><textarea value={videoPrompt} onChange={(e) => setVideoPrompt(e.target.value)} placeholder="Describe the cinematic action..." className="w-full h-24 md:h-20 bg-white/5 border border-white/10 rounded-xl p-4 text-[10px] font-medium text-white outline-none focus:border-indigo-600/50 transition-all resize-none shadow-inner" /></section>
                  <button onClick={handleGenerateVideo} disabled={videoLoading} className={`w-full py-3 md:py-4 rounded-xl font-black uppercase text-[9px] md:text-[10px] tracking-[0.3em] transition-all shadow-xl ${videoLoading ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95'}`}>{videoLoading ? 'Crafting...' : 'Synthesize Motion'}</button>
                  <button onClick={() => setIsVideoStudioOpen(false)} className="w-full py-3 text-[9px] font-black uppercase tracking-[0.4em] text-slate-600 hover:text-white transition-all">Back to Home</button>
                </>
              ) : (
                <div className="flex-1 flex flex-col gap-6">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-500">AI Dubbing Console</h3>
                  <div className="space-y-4">
                    {dubSegments.map((seg, idx) => (
                      <div key={seg.id} className="p-4 bg-white/5 border border-white/10 rounded-2xl flex flex-col gap-3 shadow-inner">
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] font-black uppercase text-indigo-400">{seg.speakerLabel} ({seg.startTime}s - {seg.endTime}s)</span>
                          <select value={seg.voice} onChange={(e) => {
                            const newSegments = [...dubSegments];
                            newSegments[idx].voice = e.target.value as VoiceName;
                            setDubSegments(newSegments);
                          }} className="bg-black text-[9px] border border-white/10 rounded px-1 text-white outline-none">
                            {VOICE_OPTIONS.map(v => <option key={v} value={v}>{v}</option>)}
                          </select>
                        </div>
                        <textarea value={seg.text} onChange={(e) => {
                          const newSegments = [...dubSegments];
                          newSegments[idx].text = e.target.value;
                          setDubSegments(newSegments);
                        }} className="w-full bg-transparent text-[11px] outline-none border-none text-white/80 h-16 resize-none" />
                      </div>
                    ))}
                  </div>
                  <button onClick={handleForgeVoiceover} className="w-full py-4 bg-white text-black rounded-xl font-black uppercase text-[10px] tracking-[0.2em] shadow-2xl hover:bg-slate-100 transition-all">Forge Dubbing</button>
                  {syncedAudioUrl && <button onClick={() => handleDownload(syncedAudioUrl, 'video')} className="w-full py-3 border border-indigo-600/30 text-indigo-400 rounded-xl font-black uppercase text-[9px] tracking-widest hover:bg-indigo-600/10 shadow-xl">Download Voice track (MP4)</button>}
                  <button onClick={() => setDubSegments([])} className="text-center text-[9px] font-black uppercase tracking-widest text-slate-600 hover:text-white transition-all">Back to Motion Studio</button>
                  <button onClick={() => setIsVideoStudioOpen(false)} className="text-center text-[9px] font-black uppercase tracking-widest text-indigo-600/50 hover:text-indigo-600 transition-all">Return Home</button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <style>{`
        ::-webkit-scrollbar { display: none !important; }
        * { -ms-overflow-style: none !important; scrollbar-width: none !important; }
        input[type="range"] { -webkit-appearance: none; background: transparent; }
        input[type="range"]::-webkit-slider-thumb { width: 16px; height: 16px; background: #4f46e5; border-radius: 50%; cursor: pointer; border: 2px solid white; box-shadow: 0 4px 10px rgba(79, 70, 229, 0.3); -webkit-appearance: none; margin-top: -6px; }
        input[type="range"]::-webkit-slider-runnable-track { width: 100%; height: 4px; background: rgba(0,0,0,0.1); border-radius: 10px; }
        @keyframes fadeIn { from { opacity: 0; transform: scale(0.98); } to { opacity: 1; transform: scale(1); } }
        .animate-in { animation: fadeIn 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default App;
