
import { 
  GoogleGenAI, 
  GenerateContentResponse, 
  VideoGenerationReferenceImage, 
  VideoGenerationReferenceType,
  Type,
  Modality
} from "@google/genai";
import { GenerationConfig, VideoGenerationConfig, SpeechSegment, VoiceName } from "../types";

// Helper to retry operations on Rate Limits (429), Server Overload (503), or Internal Errors (500)
const retryWithBackoff = async <T>(fn: () => Promise<T>, retries = 3, delay = 500): Promise<T> => {
  try {
    return await fn();
  } catch (err: any) {
    // Check for common temporary failure codes or messages
    const isRetryable = err.status === 429 || err.status === 503 || err.status === 500 ||
                        err.message?.includes('429') || err.message?.includes('503') || err.message?.includes('500') ||
                        err.message?.includes('quota') || err.message?.includes('overloaded') || err.message?.includes('Internal error');
    
    if (retries > 0 && isRetryable) {
      console.warn(`Transient error (${err.status || 'unknown'}). Retrying in ${delay}ms... (Attempts left: ${retries})`);
      await new Promise(r => setTimeout(r, delay));
      return retryWithBackoff(fn, retries - 1, delay * 2); // Exponential backoff: 500ms -> 1000ms -> 2000ms
    }
    throw err;
  }
};

const compressImage = async (base64: string, maxWidth = 800): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
      }
      const dataUrl = canvas.toDataURL('image/jpeg', 0.75);
      resolve(dataUrl.split(',')[1] || "");
    };
    img.onerror = () => resolve(base64.split(',')[1] || base64);
  });
};

export const generateArtFromSketch = async (
  sketchBase64: string,
  config: GenerationConfig,
  stylePrompt: string = ""
): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const modelToUse = config.model || 'gemini-2.5-flash-image';

  try {
    const parts: any[] = [];
    const [sketchData, refData] = await Promise.all([
      sketchBase64 ? compressImage(sketchBase64) : null,
      config.referenceImage ? compressImage(config.referenceImage) : null,
    ]);

    if (refData) {
      parts.push(
        { text: "STRUCTURAL_BLUEPRINT: Use this image ONLY as a guide for composition, layout, and subject placement." }, 
        { inlineData: { mimeType: 'image/jpeg', data: refData } }
      );
    }

    if (sketchData) {
      parts.push(
        { text: "NEW_GEOMETRY_INPUT: These lines represent additional subjects or modifications." }, 
        { inlineData: { mimeType: 'image/jpeg', data: sketchData } }
      );
    }

    const finalPrompt = `
      ROLE: MASTER NEURAL ARTIST.
      MANDATORY_TARGET_STYLE: "${stylePrompt}"
      USER INSTRUCTIONS: ${config.prompt || 'Execute a total stylistic transformation of the entire frame.'}
      NEGATIVE CONSTRAINTS: ${config.negativePrompt}, low resolution, artifacts, partial rendering, photo remnants.
    `.trim();

    parts.push({ text: finalPrompt });

    // WRAPPED IN RETRY LOGIC FOR PRO MODE STABILITY
    const response: GenerateContentResponse = await retryWithBackoff(() => ai.models.generateContent({
      model: modelToUse as any,
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: config.aspectRatio,
          ...(modelToUse === 'gemini-3-pro-image-preview' ? { imageSize: '1K' } : {})
        }
      }
    }));

    if (response.candidates && response.candidates[0]?.content?.parts) {
      const imgPart = response.candidates[0].content.parts.find(p => p.inlineData);
      if (imgPart) return `data:image/png;base64,${imgPart.inlineData.data}`;
    }
    return null;
  } catch (error: any) {
    console.error("Neural synthesis error:", error);
    throw error;
  }
};

export const generateVideoFromImage = async (
  config: VideoGenerationConfig,
  onStatusChange: (status: string) => void
): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    onStatusChange(`Initializing Veo Neural Engine (${config.resolution})...`);
    let operation;
    
    // Convert 4K to supported resolution string if necessary, though SDK supports '4K' string usually.
    // Ensure we are passing the resolution from config
    const targetResolution = config.resolution === '4K' ? '4K' : (config.resolution === '1080p' ? '1080p' : '720p');

    if (config.mode === 'reference' && config.ingredients && config.ingredients.length > 0) {
      const referenceImagesPayload: VideoGenerationReferenceImage[] = await Promise.all(
        config.ingredients.slice(0, 3).map(async (img) => ({
          image: { imageBytes: await compressImage(img), mimeType: 'image/jpeg' },
          referenceType: VideoGenerationReferenceType.ASSET,
        }))
      );
      // Video generation is usually heavier, we don't auto-retry as aggressively to avoid massive billing spikes on 429s,
      // but the SDK handles some internal retries for getting operations.
      operation = await ai.models.generateVideos({
        model: config.model,
        prompt: config.prompt || "Animate these reference assets into a cinematic scene.",
        config: { 
          numberOfVideos: 1, 
          referenceImages: referenceImagesPayload, 
          resolution: '720p', // Reference mode in Preview often locked to 720p
          aspectRatio: '16:9' 
        }
      });
    } else {
      const startData = config.startingImage ? await compressImage(config.startingImage) : null;
      const endData = config.endingImage ? await compressImage(config.endingImage) : null;
      if (!startData) throw new Error("Starting image is required for interpolation mode.");
      
      operation = await ai.models.generateVideos({
        model: config.model,
        prompt: config.prompt || "Animate this scene beautifully.",
        image: { imageBytes: startData, mimeType: 'image/jpeg' },
        ...(endData ? { lastFrame: { imageBytes: endData, mimeType: 'image/jpeg' } } : {}),
        config: { 
          numberOfVideos: 1, 
          resolution: targetResolution as any, 
          aspectRatio: config.aspectRatio 
        }
      });
    }

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      onStatusChange("Crafting high-fidelity frames...");
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }
    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    const videoBlob = await videoResponse.blob();
    return URL.createObjectURL(videoBlob);
  } catch (error) {
    console.error("Video synthesis error:", error);
    throw error;
  }
};

export const analyzeVideoForSpeech = async (videoUrl: string, voiceInstruction: string = ""): Promise<SpeechSegment[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await fetch(videoUrl);
  const blob = await response.blob();
  const base64 = await new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(blob);
  });

  const res = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: [
      { inlineData: { data: base64, mimeType: 'video/mp4' } },
      { text: `ROLE: SYLLABLE-PERFECT LIP READING EXPERT. 
        TASK: Watch this video and transcribe EVERY SINGLE WORD visually spoken.
        USER DIRECTION FOR VOICE STYLE: "${voiceInstruction || 'Normal, clear speech'}"
        
        MANDATORY: 
        1. Capture EVERY word spoken. If a mouth moves, a segment MUST exist.
        2. Timestamps MUST be syllable-accurate to the video frames.
        3. Match the DICTION and FLOW to the visual pace of the characters.
        
        Return ONLY a JSON array of objects with: id, startTime, endTime, speakerLabel, and text.` }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            startTime: { type: Type.NUMBER },
            endTime: { type: Type.NUMBER },
            speakerLabel: { type: Type.STRING },
            text: { type: Type.STRING }
          },
          required: ["id", "startTime", "endTime", "speakerLabel", "text"]
        }
      }
    }
  });

  const segments: any[] = JSON.parse(res.text || '[]');
  return segments.map(s => ({ ...s, voice: 'Zephyr' as VoiceName }));
};

export const generateMixedVoiceover = async (segments: SpeechSegment[], voiceInstruction: string = ""): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  
  const maxEndTime = Math.max(...segments.map(s => s.endTime), 5);
  const totalLengthInSamples = Math.floor((maxEndTime + 1) * 24000);
  const mixedBuffer = audioCtx.createBuffer(1, totalLengthInSamples, 24000);
  const mixedData = mixedBuffer.getChannelData(0);

  for (const segment of segments) {
    const ttsPrompt = `Style Direction: [${voiceInstruction || 'Clear and natural'}]. Say exactly: "${segment.text}"`;
    
    // We can also retry TTS calls if needed, but they are usually fast/cheap.
    const ttsRes = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: ttsPrompt }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: segment.voice } }
        }
      }
    });

    const base64 = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64) {
      const segmentBuffer = await decodeAudioData(decode(base64), audioCtx, 24000, 1);
      const segmentData = segmentBuffer.getChannelData(0);
      const startOffset = Math.floor(segment.startTime * 24000);
      
      for (let i = 0; i < segmentData.length; i++) {
        if (startOffset + i < mixedData.length) {
          mixedData[startOffset + i] += segmentData[i];
        }
      }
    }
  }

  return new Promise((resolve) => {
    const streamDest = audioCtx.createMediaStreamDestination();
    const source = audioCtx.createBufferSource();
    source.buffer = mixedBuffer;
    source.connect(streamDest);
    
    const mimeType = MediaRecorder.isTypeSupported('audio/mp4') ? 'audio/mp4' : 'audio/webm';
    const recorder = new MediaRecorder(streamDest.stream, { mimeType });
    const chunks: Blob[] = [];
    
    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType });
      resolve(URL.createObjectURL(blob));
    };
    
    recorder.start();
    source.start(0);
    source.onended = () => recorder.stop();
  });
};

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
